#!/bin/bash
#
#SBATCH --job-name=9_ET
#
#SBATCH --partition=keira
#SBATCH --qos=keira
#SBATCH --nodes=1
#   #SBATCH --exclusive
#   #SBATCH	--exclude=mb-rom[203-206]
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=5-00:00:00
#SBATCH --mem-per-cpu=1800
#SBATCH --output=./9_job.log
#SBATCH --error=./9_job.log
#

module --force purge
module restore Abi_dev

export TF_NUM_INTEROP_THREADS=1
export TF_NUM_INTRAOP_THREADS=1
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK

source ~/venvs/modnenv_v2/bin/activate

# ulimit -s unlimited

cd /globalscratch/ucl/modl/vtrinque/NLO/shg_ml_benchmarks/et/random_125/mmf_pgnn/gridsearch_scripts

python 9_train_gdsearch.py >> ./9_job.log
echo "DONE"
