# Copy the python scripts

cp 0_train_gdsearch.py 1_train_gdsearch.py
cp 0_train_gdsearch.py 2_train_gdsearch.py
cp 0_train_gdsearch.py 3_train_gdsearch.py
cp 0_train_gdsearch.py 4_train_gdsearch.py
cp 0_train_gdsearch.py 5_train_gdsearch.py
cp 0_train_gdsearch.py 6_train_gdsearch.py
cp 0_train_gdsearch.py 7_train_gdsearch.py
cp 0_train_gdsearch.py 8_train_gdsearch.py
cp 0_train_gdsearch.py 9_train_gdsearch.py

cp 0_train_gdsearch.py 10_train_gdsearch.py
cp 0_train_gdsearch.py 11_train_gdsearch.py
cp 0_train_gdsearch.py 12_train_gdsearch.py
cp 0_train_gdsearch.py 13_train_gdsearch.py
cp 0_train_gdsearch.py 14_train_gdsearch.py
cp 0_train_gdsearch.py 15_train_gdsearch.py
cp 0_train_gdsearch.py 16_train_gdsearch.py
cp 0_train_gdsearch.py 17_train_gdsearch.py
cp 0_train_gdsearch.py 18_train_gdsearch.py
cp 0_train_gdsearch.py 19_train_gdsearch.py

cp 0_train_gdsearch.py 20_train_gdsearch.py
cp 0_train_gdsearch.py 21_train_gdsearch.py
cp 0_train_gdsearch.py 22_train_gdsearch.py
cp 0_train_gdsearch.py 23_train_gdsearch.py
cp 0_train_gdsearch.py 24_train_gdsearch.py
cp 0_train_gdsearch.py 25_train_gdsearch.py
cp 0_train_gdsearch.py 26_train_gdsearch.py
cp 0_train_gdsearch.py 27_train_gdsearch.py
cp 0_train_gdsearch.py 28_train_gdsearch.py
cp 0_train_gdsearch.py 29_train_gdsearch.py

cp 0_train_gdsearch.py 30_train_gdsearch.py
cp 0_train_gdsearch.py 31_train_gdsearch.py
cp 0_train_gdsearch.py 32_train_gdsearch.py
cp 0_train_gdsearch.py 33_train_gdsearch.py
cp 0_train_gdsearch.py 34_train_gdsearch.py
cp 0_train_gdsearch.py 35_train_gdsearch.py
cp 0_train_gdsearch.py 36_train_gdsearch.py
cp 0_train_gdsearch.py 37_train_gdsearch.py
cp 0_train_gdsearch.py 38_train_gdsearch.py
cp 0_train_gdsearch.py 39_train_gdsearch.py

# Copy the submission scripts

cp 0_job.sh 1_job.sh
cp 0_job.sh 2_job.sh
cp 0_job.sh 3_job.sh
cp 0_job.sh 4_job.sh
cp 0_job.sh 5_job.sh
cp 0_job.sh 6_job.sh
cp 0_job.sh 7_job.sh
cp 0_job.sh 8_job.sh
cp 0_job.sh 9_job.sh

cp 0_job.sh 10_job.sh
cp 0_job.sh 11_job.sh
cp 0_job.sh 12_job.sh
cp 0_job.sh 13_job.sh
cp 0_job.sh 14_job.sh
cp 0_job.sh 15_job.sh
cp 0_job.sh 16_job.sh
cp 0_job.sh 17_job.sh
cp 0_job.sh 18_job.sh
cp 0_job.sh 19_job.sh

cp 0_job.sh 20_job.sh
cp 0_job.sh 21_job.sh
cp 0_job.sh 22_job.sh
cp 0_job.sh 23_job.sh
cp 0_job.sh 24_job.sh
cp 0_job.sh 25_job.sh
cp 0_job.sh 26_job.sh
cp 0_job.sh 27_job.sh
cp 0_job.sh 28_job.sh
cp 0_job.sh 29_job.sh

cp 0_job.sh 30_job.sh
cp 0_job.sh 31_job.sh
cp 0_job.sh 32_job.sh
cp 0_job.sh 33_job.sh
cp 0_job.sh 34_job.sh
cp 0_job.sh 35_job.sh
cp 0_job.sh 36_job.sh
cp 0_job.sh 37_job.sh
cp 0_job.sh 38_job.sh
cp 0_job.sh 39_job.sh


# Now replace 0_ by the correct index_

sed -i 's/0_/1_/g'   1_job.sh
sed -i 's/0_/2_/g'   2_job.sh
sed -i 's/0_/3_/g'   3_job.sh
sed -i 's/0_/4_/g'   4_job.sh
sed -i 's/0_/5_/g'   5_job.sh
sed -i 's/0_/6_/g'   6_job.sh
sed -i 's/0_/7_/g'   7_job.sh
sed -i 's/0_/8_/g'   8_job.sh
sed -i 's/0_/9_/g'   9_job.sh

sed -i 's/0_/10_/g'  10_job.sh
sed -i 's/0_/11_/g'  11_job.sh
sed -i 's/0_/12_/g'  12_job.sh
sed -i 's/0_/13_/g'  13_job.sh
sed -i 's/0_/14_/g'  14_job.sh
sed -i 's/0_/15_/g'  15_job.sh
sed -i 's/0_/16_/g'  16_job.sh
sed -i 's/0_/17_/g'  17_job.sh
sed -i 's/0_/18_/g'  18_job.sh
sed -i 's/0_/19_/g'  19_job.sh

sed -i 's/0_/20_/g'  20_job.sh
sed -i 's/0_/21_/g'  21_job.sh
sed -i 's/0_/22_/g'  22_job.sh
sed -i 's/0_/23_/g'  23_job.sh
sed -i 's/0_/24_/g'  24_job.sh
sed -i 's/0_/25_/g'  25_job.sh
sed -i 's/0_/26_/g'  26_job.sh
sed -i 's/0_/27_/g'  27_job.sh
sed -i 's/0_/28_/g'  28_job.sh
sed -i 's/0_/29_/g'  29_job.sh

sed -i 's/0_/30_/g'  30_job.sh
sed -i 's/0_/31_/g'  31_job.sh
sed -i 's/0_/32_/g'  32_job.sh
sed -i 's/0_/33_/g'  33_job.sh
sed -i 's/0_/34_/g'  34_job.sh
sed -i 's/0_/35_/g'  35_job.sh
sed -i 's/0_/36_/g'  36_job.sh
sed -i 's/0_/37_/g'  37_job.sh
sed -i 's/0_/38_/g'  38_job.sh
sed -i 's/0_/39_/g'  39_job.sh

