# Script to perform a gridsearch on some of the hyperparameters of Matten #

from pathlib import Path
from sklearn.model_selection import ParameterGrid

import os
import ruamel.yaml
import shutil

dict_grid_hparams = {
    "num_layers": [3, 5, 7, 9],
    "invariant_layers": [1, 2, 4, 6],
    "invariant_neurons": [32, 64],
    # "max_epochs": [1500],
    # "lr": [0.1, 0.01, 0.001],
    # "weight_decay": [0.001, 0.0001, 0.00001], # commented out especially since using AdamW probably
}

yaml = ruamel.yaml.YAML()
yaml.width = 4096
# yaml.preserve_quotes = True
with open('scripts_distribution_125/configs/materials_tensor.yaml') as fp:
    data = yaml.load(fp)
for i, dct in enumerate(ParameterGrid(dict_grid_hparams)):
    for elem in data:
        if elem=="model":
            data[elem]["num_layers"] = dct['num_layers']
            data[elem]["invariant_layers"] = dct['invariant_layers']
            data[elem]["invariant_neurons"] = dct['invariant_neurons']
    os.makedirs(name=f"scripts_distribution_125_gdsearch_{i}/configs")
    yaml.dump(data, Path(f"scripts_distribution_125_gdsearch_{i}/configs/materials_tensor.yaml"))
    shutil.copy(src="scripts_distribution_125/job.sh", dst=f"scripts_distribution_125_gdsearch_{i}/job.sh")
    shutil.copy(src="scripts_distribution_125/train_materials_tensor.py",
                dst=f"scripts_distribution_125_gdsearch_{i}/train_materials_tensor.py"
                )
