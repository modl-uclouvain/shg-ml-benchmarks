#!/bin/bash -l

#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --constraint=Tesla
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=60G

#SBATCH --time=0-20:00:00
#SBATCH --job-name=gdsearch
#SBATCH --output=job.log
#SBATCH --error=job.log


#ulimit -s unlimited; export MKL_NUM_THREADS=1; export OMP_NUM_THREADS=1; export OPENBLAS_NUM_THREADS=1

module --force purge; module load releases/2023b intel Python/3.11.5-GCCcore-13.2.0
source /home/ucl/modl/vtrinque/venvs/mattenv/bin/activate

cd /globalscratch/ucl/modl/vtrinque/NLO/grah_models/matten/prod_shg/gridsearch/other_holdout_sets/scripts_random_125_gdsearch_19

python train_materials_tensor.py
